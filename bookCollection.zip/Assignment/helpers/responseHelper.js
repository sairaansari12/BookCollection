
const post = (res, message, resData, code = 200) => {
  return res.status(200).json({
    code: code,
    message: message,
    body: resData,
  });
};

const unauthorized = (res, message, code = 401) => {
  return res.status(code).json({
    code: code,
    message: message,
    body: null,
  });
};

const error = (res, message, code = 400) => {
  return res.status(code).json({
    code: code,
    message: message,
    body: null,
  });
};



export {
  post,
  error,
  unauthorized,
  
};
