const moment = require('moment');

//ptui
var methods={

 timestamp : () => {
	return time = moment.utc().format('X');
},

checkParameterMissing :   function(params)
{

for(var k=0;k<params.length;k++)
{

if(params[k]==undefined || params[k]=="")

{
 return true
}

if(k==params.lenth-1)
return false

}

},

}
module.exports=methods
