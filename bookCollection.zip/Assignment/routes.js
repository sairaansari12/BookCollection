const routes = require("express").Router();
import bookCtrl from "./controllers/books";

import { error } from "./helpers/responseHelper";

routes.use("/books", bookCtrl);

routes.use((req, res) => {
  return error(
    res,
    "Please again check the url,This path is not specified",
    404
  );
});

module.exports = routes;
