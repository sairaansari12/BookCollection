require('dotenv-flow').config()
import { createServer } from "http";
import express from "express";
global.appstrings = require("./language.json")["en"];
const bodyParser = require("body-parser");
const app = express();
const server = createServer(app);
const PORT = process.env.APP_PORT || 9070;
const routes = require("./routes");
const connection = require("./models/connection");



app.use(
  bodyParser.json({
    limit: "50mb",
  })
);






app.use("/api", routes);



server.listen(PORT, () => {
  console.log(`Server Listening on PORT ${PORT}`);
});

