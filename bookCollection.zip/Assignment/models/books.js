const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const bookSchema=new Schema({
    bookName: {
        type: String
      },
      authorName: {
        type: String
      },
      publishedDate: {
        type: String
      },
      pages: {
        type: Number
      },
  
      stock: {
        type: Number
      },
      createdAt:{
      type: Date,
      default: Date.now
      }



})

module.exports = mongoose.model('bookModal', bookSchema);
