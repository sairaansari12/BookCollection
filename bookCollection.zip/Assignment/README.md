# BookCollection

### Prerequisites to run the project:
1. Install Nodejs (Currently using : Node 16.20)


### Steps to Run the project
1. Open Visual Studio code or any Code Editor
2. Open Project Folder
3. Run Command : npm install
4. Run Command: npm run local

//Now server will start listening on the port 9070
Run api on postman by using following details :


### API Details
 Follow the collection : 

https://documenter.getpostman.com/view/7150918/2s9YsKfBtp







   
