const router = require("express").Router();
import { post } from "../helpers/responseHelper";
import { checkParameterMissing } from "../helpers/common";
const bookSchema = require("../models/books");
const { body, validationResult } = require("express-validator");

router.post(
  "/create",
  [
    body("name", "Enter a valid name").isLength({ min: 3 }),
    body("author", "Enter a valid name").isLength({ min: 3 }),
    body("pages", "Pages cannot be blank").exists(),
    body("stock", "Stock cannot be 0").notEmpty().isInt({ min: 1 }),
  ],
  async (req, res) => {
    const params = req.body;
    // If there are errors, return Bad request and the errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    try {
      // Check whether the user with this email exists already
      let user = await bookSchema.findOne({ bookName: params.name });
      if (user) {
        return post(
          res,
          "Sorry a book with this name already exists",
          null,
          400
        );
      }

      // Create a new user
      user = await bookSchema.create({
        bookName: params.name,
        authorName: params.author,
        pages: params.pages,
        publishedDate: params.publishedDate,
        stock: params.stock,
      });

      return post(res, appstrings.success, user);
    } catch (error) {
      console.error(error.message);
      return post(res, error.message, null, 400);
    }
  }
);

router.get("/list", async (req, res, next) => {
  var params = req.query;

  var page = 1;
  var limit = 20;

  if (params.page) page = params.page;
  if (params.category) category = params.category;

  if (params.limit) limit = Number(params.limit);
  var offset = (page - 1) * limit;

  try {
    bookSchema.find(
      { userId: params.userId },
      {},
      { skip: offset, limit: limit },
      function (err, results) {
        if (results) return post(res, appstrings.success, results);
        else return post(res, err.message, null, 400);
      }
    );
  } catch (e) {
    console.log(e);
    return post(res, e.message, null, 400);
  }
});

router.put(
  "/update/:id",
  [
    body("author", "Enter a valid name").isLength({ min: 3 }),
    body("pages", "Pages cannot be blank").exists(),
    body("stock", "Stock cannot be 0").notEmpty().isInt({ min: 1 }),
  ],
  async (req, res) => {
    const params = req.body;
    // If there are errors, return Bad request and the errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    const { author, stock, publishedDate, pages } = req.body;
    try {
      // Create a newNote object
      const newNote = {};
      if (author) {
        newNote.authorName = author;
      }
      if (publishedDate) {
        newNote.publishedDate = publishedDate;
      }
      if (stock) {
        newNote.stock = stock;
      }
      if (pages) {
        newNote.pages = pages;
      }

      // Find the note to be updated and update it
      let note = await bookSchema.findById(req.params.id);
      if (!note) {
        return post(res, "Not Found", null, 404);
      }
      note = await bookSchema.findByIdAndUpdate(
        req.params.id,
        { $set: newNote },
        { new: true }
      );
      return post(res, appstrings.success, note);
    } catch (error) {
      console.error(error.message);
      return post(res, error.message, null, 400);
    }
  }
);

router.get("/detail/:bookId", async (req, res, next) => {
  try {
    var params = req.params;
    var bookId = params.bookId;
    let responseNull = checkParameterMissing([bookId]);
    if (responseNull) return post(res, appstrings.required_field, null, 400);

    let user = await bookSchema.findOne({ _id: bookId });
    if (!user) {
      return post(res, "Sorry a book with this Id does not exists", null, 400);
    } else return post(res, appstrings.success, user);
  } catch (e) {
    return post(res, e.message, null, 400);
  }
});

router.delete("/delete/:id", async (req, res) => {
  try {
    // Find the note to be delete and delete it
    let note = await bookSchema.findById(req.params.id);
    if (!note) {
      return post(res, "Not Found", null, 404);
    }

    note = await bookSchema.findByIdAndDelete(req.params.id);
    return post(res, appstrings.success, { note: note });
  } catch (error) {
    console.error(error.message);
    res.status(500).send("Internal Server Error");
  }
});
export default router;
